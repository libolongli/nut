<?php
namespace app\index\controller;
use Think\Controller;
use Think\Db;
use app\Index\controller\Common;
class Group extends Common
{
    /*群组列表*/
    public function index(){
        $pageParam    = ['query' =>[]];
        $ser=$where=[];
        $ser['name']=input('name','');
        $ser['id']=input("id","");
        $pageParam['query']=$ser;
        if(!empty($ser['name'])){
            $where['g.name']=array('like','%'.$ser['name'].'%');
            $pageParam['page']=1;
        }
        if (!empty($ser['id'])){
            $where['g.id']=$ser['id'];
            $pageParam['page']=1;
        }
        $this->assign('ser',$ser);
        $data=db('group')->alias('g')->where($where)->join('__USER__ u','g.createrId=u.id')->field('g.*,u.name as oname,u.mobile as ophone,u.id oid')->paginate(15, false, $pageParam);
        $this->assign('data',$data);
        return view();
    }
    
}